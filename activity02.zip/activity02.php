<!DOCTYPE html>
<html>
<head>
	<title>Activity 02</title>
</head>
<body>
<h1>First PHP Program</h1>

<?php
$name = 'John Doe';
$Full_Name = 'Tatni John Doe';
$Age = '20 years';
$Date_of_Birth = '1996/01/01';
$Address = 'No 102/3, Moratuwa';
$Occupation = 'Teacher';
$School = 'Kottawa North Dharmapala Vidyalaya';
$University = 'University of Monash';

echo "1.Name: $name";
echo "<br>";
echo "2.Full Name: $Full_Name";
echo "<br>";
echo "3.Age: $Age";
echo "<br>";
echo "4.Date of Birth: $Date_of_Birth";
echo "<br>";
echo "5.Address:$Address";
echo "<br>";
echo "6.Occupation: $Occupation";
echo "<br>";
echo "7.School: $School";
echo "<br>";
echo "8.University: $University";
?>
</body>
</html>